package com.example.k8sdashboard.service;

import com.example.k8sdashboard.dto.DeploymentInfo;
import io.fabric8.kubernetes.api.model.apps.Deployment;
import io.fabric8.kubernetes.api.model.apps.DeploymentStatus;
import io.fabric8.kubernetes.client.KubernetesClient;
import io.fabric8.kubernetes.client.KubernetesClientBuilder;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class K8sService {

    private final KubernetesClient client;

    @Value("${k8s.namespace:default}")
    private String namespace;

    public K8sService() {
        // Автоматически читает ~/.kube/config
        this.client = new KubernetesClientBuilder().build();
        log.info("Kubernetes client initialized. Master URL: {}", client.getMasterUrl());
    }

    /**
     * Получить список всех деплойментов в namespace
     */
    public List<DeploymentInfo> getAllDeployments() {
        return client.apps().deployments()
                .inNamespace(namespace)
                .list()
                .getItems()
                .stream()
                .map(this::toDeploymentInfo)
                .collect(Collectors.toList());
    }

    /**
     * Получить информацию о конкретном деплойменте
     */
    public DeploymentInfo getDeployment(String name) {
        Deployment dep = client.apps().deployments()
                .inNamespace(namespace)
                .withName(name)
                .get();
        if (dep == null) {
            throw new RuntimeException("Deployment not found: " + name);
        }
        return toDeploymentInfo(dep);
    }

    /**
     * Перезапустить деплоймент (rollout restart)
     */
    public void restart(String name) {
        log.info("Restarting deployment: {}/{}", namespace, name);
        client.apps().deployments()
                .inNamespace(namespace)
                .withName(name)
                .rolling().restart();
    }

    /**
     * Остановить деплоймент — scale down to 0
     */
    public void stop(String name) {
        log.info("Stopping deployment: {}/{}", namespace, name);
        client.apps().deployments()
                .inNamespace(namespace)
                .withName(name)
                .scale(0);
    }

    /**
     * Запустить деплоймент — scale up to 1
     */
    public void start(String name) {
        log.info("Starting deployment: {}/{}", namespace, name);
        client.apps().deployments()
                .inNamespace(namespace)
                .withName(name)
                .scale(1);
    }

    /**
     * Установить конкретное количество реплик
     */
    public void scale(String name, int replicas) {
        log.info("Scaling deployment {}/{} to {} replicas", namespace, name, replicas);
        client.apps().deployments()
                .inNamespace(namespace)
                .withName(name)
                .scale(replicas);
    }

    // ---- Маппинг ----

    private DeploymentInfo toDeploymentInfo(Deployment dep) {
        DeploymentStatus st = dep.getStatus();
        int desired  = getOrZero(dep.getSpec().getReplicas());
        int ready    = getOrZero(st.getReadyReplicas());
        int available = getOrZero(st.getAvailableReplicas());

        String status = resolveStatus(desired, ready);

        return new DeploymentInfo(
                dep.getMetadata().getName(),
                dep.getMetadata().getNamespace(),
                desired,
                ready,
                available,
                status
        );
    }

    private String resolveStatus(int desired, int ready) {
        if (desired == 0) return "STOPPED";
        if (ready == 0)   return "STOPPED";
        if (ready < desired) return "PARTIAL";
        return "RUNNING";
    }

    private int getOrZero(Integer value) {
        return value != null ? value : 0;
    }

    @PreDestroy
    public void close() {
        client.close();
    }
}
