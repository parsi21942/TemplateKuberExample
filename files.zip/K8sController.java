package com.example.k8sdashboard.controller;

import com.example.k8sdashboard.dto.DeploymentInfo;
import com.example.k8sdashboard.service.K8sService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Slf4j
@Controller
@RequiredArgsConstructor
public class K8sController {

    private final K8sService k8sService;

    /**
     * Главная страница — список всех деплойментов
     */
    @GetMapping("/")
    public String dashboard(Model model) {
        try {
            List<DeploymentInfo> deployments = k8sService.getAllDeployments();
            model.addAttribute("deployments", deployments);
        } catch (Exception e) {
            log.error("Failed to load deployments", e);
            model.addAttribute("error", "Ошибка подключения к Kubernetes: " + e.getMessage());
        }
        return "dashboard";
    }

    /**
     * Перезапустить деплоймент
     */
    @PostMapping("/restart/{name}")
    public String restart(@PathVariable String name, RedirectAttributes ra) {
        try {
            k8sService.restart(name);
            ra.addFlashAttribute("success", "Деплоймент «" + name + "» перезапущен ✓");
        } catch (Exception e) {
            log.error("Restart failed for: {}", name, e);
            ra.addFlashAttribute("error", "Ошибка перезапуска: " + e.getMessage());
        }
        return "redirect:/";
    }

    /**
     * Остановить деплоймент
     */
    @PostMapping("/stop/{name}")
    public String stop(@PathVariable String name, RedirectAttributes ra) {
        try {
            k8sService.stop(name);
            ra.addFlashAttribute("success", "Деплоймент «" + name + "» остановлен ✓");
        } catch (Exception e) {
            log.error("Stop failed for: {}", name, e);
            ra.addFlashAttribute("error", "Ошибка остановки: " + e.getMessage());
        }
        return "redirect:/";
    }

    /**
     * Запустить деплоймент
     */
    @PostMapping("/start/{name}")
    public String start(@PathVariable String name, RedirectAttributes ra) {
        try {
            k8sService.start(name);
            ra.addFlashAttribute("success", "Деплоймент «" + name + "» запущен ✓");
        } catch (Exception e) {
            log.error("Start failed for: {}", name, e);
            ra.addFlashAttribute("error", "Ошибка запуска: " + e.getMessage());
        }
        return "redirect:/";
    }

    /**
     * Масштабировать деплоймент
     */
    @PostMapping("/scale/{name}")
    public String scale(@PathVariable String name,
                        @RequestParam int replicas,
                        RedirectAttributes ra) {
        try {
            k8sService.scale(name, replicas);
            ra.addFlashAttribute("success",
                    "Деплоймент «" + name + "» масштабирован до " + replicas + " реплик ✓");
        } catch (Exception e) {
            log.error("Scale failed for: {}", name, e);
            ra.addFlashAttribute("error", "Ошибка масштабирования: " + e.getMessage());
        }
        return "redirect:/";
    }

    /**
     * REST API — статус одного деплоймента (для AJAX авто-обновления)
     */
    @GetMapping("/api/status/{name}")
    @ResponseBody
    public DeploymentInfo statusApi(@PathVariable String name) {
        return k8sService.getDeployment(name);
    }

    /**
     * REST API — список всех деплойментов (для AJAX авто-обновления)
     */
    @GetMapping("/api/deployments")
    @ResponseBody
    public List<DeploymentInfo> deploymentsApi() {
        return k8sService.getAllDeployments();
    }
}
